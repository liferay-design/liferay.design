---
title: 'Guild Manifesto'
description: 'page-description'
---

## TODO: guild manifesto
