---
title: 'Europe, Middle East, Africa Guild Index'
description: 'EMEA'
order: 2
---

## TODO: Design EMEA Handbook Homepage
