---
title: 'Your First Week in LA'
description: 'description'
order: 1
---

## Welcome!

We're so glad you're here.

To make your first few days as easy and profitable for you as possible, we've set up a series of checklists for you to use.

The current version is in the form of a [Trello board](https://trello.com/b/OmS5kJW5):

![Liferay.Design Onboarding Trello](/images/handbook/na/trello-board.png 'Onboading Checklist')

<img src="/images/handbook/na/copy-board.png" alt="how to copy a Trello board" style="width: 50%; float: right;" /> Your first task, should you choose to accept it, is to copy the board and share it with your manager.

If at any point you come across anything that it outdated or wrong, please take action and fix it. If you think anything can be improved upon please do not hesitate to bring it up to the team for discussion.
