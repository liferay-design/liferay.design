---
title: 'Communication Tools'
description: 'Can you hear me now?'
order: 1
---

Good communication is essential to success as a designer.

We employ a variety of tools, every project and product team is different in how they communicate. It is your responsibility to adapt, learn, and improve the communication methods in whichever team you're working with.

## General Principles

1. Be Considerate
1. Be Clear
1. Be Concise

## Tools

### Hangouts

### Slack

### Skype
