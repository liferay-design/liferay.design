---
title: 'Design Tools'
description: 'Frequently Used Tools'
order: 2
---

## General Principles

## Current Stack

### Adobe

#### Illustrator

#### Lightroom

#### Photoshop

#### XD

### Figma

### Invision

### Sketch

### Sublime Text

### VS Code

## New Tools

### FramerX
